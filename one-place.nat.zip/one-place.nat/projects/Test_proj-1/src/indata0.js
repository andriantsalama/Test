var data = {
	images:[['file:///G:/Dev2024/images/Google-Pixel_4A.png','file:///G:/Dev2024/images/SONY-Xperia_Pro.png','file:///G:/Dev2024/images/succes-commercial-richesses-baisse.jpg'],['https://m.media-amazon.com/images/I/61lqgGTyoeL.jpg','https://m.media-amazon.com/images/I/61TSS7UVFaL.jpg','https://m.media-amazon.com/images/I/71YI3kvzGdL.jpg','https://m.media-amazon.com/images/I/61c6YOJvj4L.jpg','https://m.media-amazon.com/images/I/61cqXt0bJvL.jpg']],
	asins:['NOPRODUCTS','B08TQHK8S9'],
	location:['com','co.uk'],
	annotations:[[],[]]
}